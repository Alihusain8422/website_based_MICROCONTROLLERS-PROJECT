const express = require("express");
const path = require("path");
var bodyParser = require('body-parser');
var mongoose = require('mongoose')
 
var fs = require('fs');

require('dotenv/config');


require("./db/conn");
var multer = require('multer');
 
var storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads')
    },
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now())
    }
});
 
var upload = multer({ storage: storage });

const login = require("./models/login");

const InsertDatas = require("../src/models/inserts")
const ContactDatas = require("../src/models/contact")
const hbs = require("hbs");
const app = express();
const port = process.env.PORT || 3000;
const staticpath =  path.join(__dirname, "../public");
const templatepath =  path.join(__dirname, "../templates/views");
const partialpath =  path.join(__dirname, "../templates/partials");
app.use('/css', express.static(path.join(__dirname, "../node_modules/bootstrap/dist/css")));
app.use(express.json());
app.use(express.urlencoded({extended:true}));


app.use('/js', express.static(path.join(__dirname, "../node_modules/bootstrap/dist/js")));

app.use('/jq', express.static(path.join(__dirname, "../node_modules/jquery/dist")));
app.use(express.static(staticpath))
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
 
// Set EJS as templating engine 
app.set("view engine", "ejs");
app.set("view engine","hbs");
app.set("views",templatepath);
hbs.registerPartials(partialpath);

app.get("/",(req,res)=>{
    res.render("index");
})
app.get("/contact",(req,res)=>{
    res.render("contact");
})
app.get("/login",(req,res)=>{
    res.render("login");
})
app.get("/about",(req,res)=>{
    res.render("about");
})
app.get("/loginhome",(req,res)=>{
    res.render("loginhome");
})
app.get("/insert",(req,res)=>{
    res.render("insert");
})
app.get("/gallery",(req,res)=>{
    res.render("gallery");
})
app.get("/userdata",(req,res)=>{
    res.render("userdata");
})
app.get("/location",(req,res)=>{
    res.render("location");
})


app.post("/contact",async(req,res)=>{
    
        const name = req.body.name;
        const email = req.body.email;
        const msg = req.body.msg;
        const phone = req.body.phone;
        
        //const user = await elect.findOne({username:username});
        console.log(`${name} email is ${email} ${msg} ${phone}  `)
        const contactData = new ContactDatas(req.body);
        await contactData.save();
        res.status(201)
        
     
});
app.post("/login",async(req,res)=>{
    try {
        const username = req.body.username;
        const password = req.body.password;
        //const user = await elect.findOne({username:username});
        console.log(`${username} password is ${password}`)
       if(password === "admin"){
           res.status(201).render("loginhome");
          
       }
        
    } catch (error) {
        res.status(400).send("invalid email")
        
    }
});

app.post("/inserts", async(req, res)=>{
    try {
            //res.send(req.body);
        const cname = req.body.cname
        console.log(`${cname}`)  
        const insertData = new InsertDatas(req.body);
         await insertData.save();
         res.status(201).render("loginhome")

    } catch (error) {
        res.status(500).send(error)
    }

    
})
app.post("/contact",(req,res)=>{

    res.sendFile(path.join(__dirname,"contact"));
})



app.listen(port,()=>{
    console.log(`Server is running at number ${port}`);
})