const mongoose = require('mongoose');
var dataSchema = new mongoose.Schema({
    cname:{
        type:String,
        required:true
    },
    dname:{
        type:String,
        required:true

    }
});

mongoose.model('Data', dataSchema);