
const mongoose = require("mongoose");

const contactSchema = mongoose.Schema({
        name:{
            type:String
        },
        email:{
            type:String
            

        },
        msg:{
            type: String
        },
        phone:{
            type: Number
        }



})
 const ContactDatas = mongoose.model("ContactData",contactSchema);

 module.exports = ContactDatas;