const mongoose = require("mongoose");

const insertSchema = mongoose.Schema({
        cname:{
            type:String
        },
        dname:{
            type:String,
            

        },/*
        image:{
            data: Buffer,
            contentType: String
        }*/

})
 const InsertDatas = mongoose.model("InsertData",insertSchema);

 module.exports = InsertDatas;